# AgentMesh Fleet — Security Audit & Review Package

Welcome to the **AgentMesh Fleet** repository package. This repository contains the complete source code, security configuration, agent implementations, and automated test suites for the AgentMesh Enterprise Multi-Agent System.

---

## Architecture Overview
AgentMesh is an enterprise multi-agent architecture built on **Google Cloud Platform (GCP)** and **Google Agent Development Kit (`google-adk` v2.6+)** with **Gemini 3.5 Flash** models via Vertex AI.

All inter-agent communication, Firestore database queries, and external API tool executions (e.g. GitHub API) are strictly mediated through a centralized 6-stage Zero-Trust **AgentMesh Gateway** (`agentmesh-gateway`), featuring:
1. **OIDC Authentication**: Verifies Cloud Run Service Account OIDC ID Tokens.
2. **Identity Verification**: Enforces agent active status in `agent_registry`.
3. **Policy Evaluation**: Enforces collection RBAC (`allowedCollections`) & least-privilege DENY policies.
4. **Guard Pipeline / Threat Shield**: Inbound/Outbound inline scanning for secret leaks, PII, and prompt injection/jailbreak attempts via Gemini 3.5 Flash classification.
5. **Tool Execution & Workflow Ownership Check**: Ensures agents can only write to workflow records they are involved in.
6. **Immutable Audit Logging**: Logs all decisions directly to Firestore `audit_log`.

---

## Live System Services (Region: `asia-south1`)

| Service Name | Live Cloud Run Service URL | Description |
| :--- | :--- | :--- |
| **Control Plane Web Dashboard** | `https://agentmesh-dashboard-138003672216.asia-south1.run.app` | Next.js 16 Control Plane UI for audit logging, policy simulation, and Human-in-the-Loop approvals |
| **AgentMesh Gateway** | `https://agentmesh-gateway-138003672216.asia-south1.run.app` | Centralized 6-stage Zero-Trust security gateway |
| **Fraud & Finance Agent** | `https://agentmesh-fraud-finance-138003672216.asia-south1.run.app` | Autonomous invoice anomaly detection & workflow execution |
| **IT & Security Agent** | `https://agentmesh-it-security-138003672216.asia-south1.run.app` | Security risk scanner & GitHub incident ticket creation agent |
| **Compliance Agent** | `https://agentmesh-compliance-138003672216.asia-south1.run.app` | Policy review & zero-trust compliance assessment agent |
| **Expense Approval Agent** | `https://agentmesh-expense-approval-138003672216.asia-south1.run.app` | Expense review & policy validation agent |
| **HR Leave Assistant Agent** | `https://agentmesh-hr-leave-138003672216.asia-south1.run.app` | HR leave requests processing agent |
| **Legal Contract Agent** | `https://agentmesh-legal-contract-138003672216.asia-south1.run.app` | Contract NDA & terms review agent |

---

## Infrastructure & Configuration
* **GCP Project ID**: `agentmesh-fleet-2026`
* **GCP Region**: `asia-south1`
* **GitHub Fleet Repo**: `https://github.com/ssurekumar01111-hue/agentmesh-fleet.git`
* **GitHub Sandbox Target Repo**: `https://github.com/ssurekumar01111-hue/Northbridge-Retail-Co.`

---

## Key Documentation Pointers
For detailed architectural blueprints, phase implementation history, and design details:
- **`docs/architecture.md`**: System topology, threat models, 6-stage gateway pipeline diagrams.
- **`docs/build-plan.md`**: Step-by-step implementation milestones and verification criteria across all phases.

---

## Repository Structure
```
├── AUDIT_README.md         # Audit summary (this document)
├── README.md               # Main project README
├── gateway/                # AgentMesh Gateway source code, armor.py, and tests
├── agents/                 # Autonomous ADK Reasoning Agents
│   ├── fraud-finance/
│   ├── it-security/
│   ├── compliance/
│   ├── expense-approval/
│   ├── hr-leave/
│   └── legal-contract/
├── dashboard/              # Control Plane Web Dashboard (Next.js 16 + Tailwind)
├── docs/                   # Full system documentation & architecture diagrams
└── test_e2e_workflow.py   # Full fleet end-to-end integration test suite
```
